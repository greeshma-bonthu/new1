
const activepage = window.location.href;
console.log(activepage);

